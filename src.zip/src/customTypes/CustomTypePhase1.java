package customTypes;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

import org.apache.hadoop.io.Writable;

public class CustomTypePhase1 implements Writable {

	@Override
	public void readFields(DataInput dataInput) throws IOException {
		// TODO Auto-generated method stub

	}

	@Override
	public void write(DataOutput dataOutput) throws IOException {
		// TODO Auto-generated method stub

	}

}
