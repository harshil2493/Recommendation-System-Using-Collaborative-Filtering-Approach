package utils;

import java.util.ArrayList;
import java.util.Collections;

public class TestFile {
	public static void main(String[] args) {
		// String a = "203:201, 209";
		//
		// String[] aSplit =
		// a.split(Protocols.FRIEND_EDGE_SPLIT)[1].split(Protocols.FRIEND_LIST_SEPARATOR);
		// System.out.println(aSplit[0]);

		ArrayList<Integer> x = new ArrayList<Integer>();
		x.add(1);
		x.add(3);
//
		x.add(2);
		x.add(9);
		x.add(7);
		x.add(7);
		x.add(7);
//		x.add(7);
//		x.add(7);
//		x.add(7);
		System.out.println(x);

		Collections.shuffle(x);
		System.out.println(x);

		System.out.println(
				"TRAIN" + x.subList(0, (int) (x.size() * 0.7)));

		System.out.println(x.subList((int) (x.size() * 0.7), x.size()));

		String f = "efef,";

		System.out.println(f.substring(0, f.length() - 1));
		
		String[] y = "533812,403,".split(",");
		System.out.println("Y L" + y.length);

	}
}
